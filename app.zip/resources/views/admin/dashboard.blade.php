@extends('layouts.admin' , ['title' => 'dashboard'])
@section('content')
    <div class="row">
        <div class="col lg-4"><h1>content</h1></div>
        <div class="col lg-4"><marquee behavior="" direction=""><h1>super admin content</h1></marquee></div>
        <div class="col lg-4"><p>admin content</p></div>
    </div>
@endsection
{{-- @section('script')
    <script>alert= 5</script>
@endsection --}}