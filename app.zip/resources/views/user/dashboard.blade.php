@extends('layouts.user' , ['title' => 'event managment'])
@section('content')
<div class="tab-content" id="pills-tabContent">
  <h3>I do not know</h3>  
</div>
@endsection